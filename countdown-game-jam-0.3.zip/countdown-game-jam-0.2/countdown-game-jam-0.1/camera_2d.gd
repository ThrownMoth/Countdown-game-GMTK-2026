extends Camera2D

var paused=false
var time=60.0
var CountdownSpeed=1.0
var MaxTime := globalData.MaxTime

@onready var upgradeGUI = preload("res://upgrades_gui.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if !paused:
		time = max(0,time-CountdownSpeed*delta)
		time = min(time,60 *100-0.01)
	$RichTextLabel.modulate= lerp($RichTextLabel.modulate,Color(1,1,1,$RichTextLabel.modulate.a),delta)
	$RichTextLabel.text="[center]"
	
	if floori(time/60)>9:
		$RichTextLabel.text=$RichTextLabel.text+str(floori(time/60))
	else:
		$RichTextLabel.text=$RichTextLabel.text+"0"+str(floori(time/60))
	if floori(time)%60>9:
		$RichTextLabel.text=$RichTextLabel.text+":"+str(floori(time)%60)
	else:
		$RichTextLabel.text=$RichTextLabel.text+":0"+str(floori(time)%60)
	if floori(time*100)%100>9:
		$RichTextLabel.text=$RichTextLabel.text+"."+str(floori(time*100)%100)
	else:
		$RichTextLabel.text=$RichTextLabel.text+".0"+str(floori(time*100)%100)
	
	if time<=0:
		get_tree().call_deferred("reload_current_scene")
	#if time == 30:
	#	$UpgradesGui.visible = true
		

func showGui():
	$UpgradesGui.visible != $UpgradesGui.visible


func add_time(amount):
	paused=true
	if amount>0:
		$RichTextLabel.modulate=Color(0,min(amount/3,1),0)
	else:
		$RichTextLabel.modulate=Color(min(-amount/3,1),0,0)
	if abs(amount)>=5:
		for i in range(100):
			time+=amount*0.01
			await get_tree().create_timer(0.01).timeout
	else:
		for i in range(floor(abs(amount)*20)):
			time+=0.05*sign(amount)
			await get_tree().create_timer(0.01).timeout
	
	paused=false

extends Node

var UpgradeArray = ["BonusTime","ExtraKnockback","Parry","MultiKill","ExDamage","FastReturn","HeartStun","BurningHeart","SlowHeart","SpeedBoost","MoreTime"]

var Upgrades = {
	#melee
	"BonusTime":["res://icon.svg","Gives extra time for every enemy killed."],
	"ExtraKnockback":["res://icon.svg","Enemies get knocked back further."],
	"Parry":["res://icon.svg","Can parry projectiles."],
	
	#Throw
	"MultiKill":["res://icon.svg","Gives extra time for killing multiple enemies with one axe throw."],
	"ExDamage":["res://icon.svg","Gives temporary damage when the axe returns."],
	"FastReturn":["res://icon.svg","The axe returns faster."],
	
	#Heart
	"HeartStun":["res://icon.svg","Enemies hit by the explosion get stunned."],
	"BurningHeart":["res://icon.svg","Leaves the area around it burning instead of an explosion."],
	"SlowHeart":["res://icon.svg","Slows time for 5 seconds."],
	
	#General
	"SpeedBoost":["res://icon.svg","killing an enemy gives a small speed boost"],
	"MoreTime":["res://icon.svg","Enemies will give more time below 30 seconds."],
	
	
}

func ApplyUpgrade(upgrade):
	match upgrade:
		"BonusTime":
			globalData.BonusTimeStack += 1.0
		"ExtraKnockback":
			globalData.ExtraKnockback += 1.0
		"Parry":
			get_tree().current_scene.Player.UnlockedParry = true
			
		"MultiKill":
			pass
		"ExDamage":
			globalData.AxetraDamage += 1.0
		"FastReturn":
			globalData.AxetraReturnSpeed += 100.0
		
		"HeartStun":
			pass
		"BurningHeart":
			pass
		"SlowHeart":
			pass
		
		"SpeedBoost":
			get_tree().current_scene.Player.unlockedSpeedBoost = true
			globalData.SpeedBoost += 100
		"MoreTime":
			globalData.MoreTime += 1.0

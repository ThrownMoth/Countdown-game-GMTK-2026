extends Area2D

var Speed = 2000
var angle:=0.0
var velocity:=Vector2(0,0)
@onready var explosion:=preload("res://Explosion.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	velocity=Vector2(Speed,0).rotated(angle)
	await get_tree().create_timer(0.5).timeout
	var newExplosion:=explosion.instantiate()
	get_tree().current_scene.add_child(newExplosion)
	newExplosion.position=get_tree().current_scene.Player.position
	
	get_tree().current_scene.Player.position=position
	
	call_deferred("queue_free")

func _physics_process(delta: float) -> void:
	position += velocity*delta
	

extends Node2D

var CountdownSpeed := 2.0
var paused := false
var time:=10.0
@onready var camera:=$Camera2D
@onready var Player:=$Player

# Called when the node enters the scene tree for the first time.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Camera2D.position=$Camera2D.position+(($Player.position-$Camera2D.position)+(get_global_mouse_position()-$Camera2D.position)*0.2) *delta
	time=$Camera2D.time

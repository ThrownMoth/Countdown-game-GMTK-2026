extends Area2D

var velocity:=Vector2(1500,0)
var returning:=false
var angle:=0.0
var colliding:=false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	velocity=velocity.rotated(angle)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Line2D.rotation+=delta*2*PI*3
	position+=velocity*delta
	if !returning:
		
		velocity=velocity.move_toward(Vector2.ZERO,2000*delta)
		if velocity.distance_to(Vector2.ZERO)<50:
			returning=true
	else:
		velocity=velocity.move_toward(Vector2(2000,0).rotated(get_angle_to(get_tree().current_scene.Player.position)),(4000 + globalData.AxetraReturnSpeed)*delta)
		
	if colliding and returning:
		get_tree().current_scene.Player.axeThrown=false
		get_tree().current_scene.Player.CanAxetraDamage=true
		call_deferred("queue_free")


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		colliding=true

func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("Player"):
		colliding=false


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy"):
		area.take_damage(3)

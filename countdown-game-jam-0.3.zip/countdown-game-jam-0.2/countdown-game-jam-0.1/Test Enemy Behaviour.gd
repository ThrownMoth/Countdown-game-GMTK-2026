extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var enemy:Object=get_parent()
	var player:Object=get_tree().current_scene.Player
	enemy.moveVelocity=Vector2(500,0).rotated(get_angle_to(player.position))

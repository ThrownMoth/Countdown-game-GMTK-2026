extends Area2D


@export var SPEED = 5*00.0
const JUMP_VELOCITY = -400.0
@export var maxHealth:=5.0
var Health := 5.0
var Player = null
var TargetPos = Vector2.ZERO
var moveVelocity:=Vector2(0,0)
var knockbackVelocity:=Vector2(0,0)
var velocity:=Vector2(0,0)
var softCollVelocity:=Vector2(0,0)
@export var contactDamage:=2.0
@export var knockbackMulti:=1.0
signal death
var deathEmitted:=false
@export var timeBonus:=4.0
signal hit
@onready var softCollider=$SoftCollision

func _ready() -> void:
	Health=maxHealth



func _physics_process(delta: float) -> void:
		

	$"Health Outline/Health Lerp".points[1].x=lerp($"Health Outline/Health Lerp".points[1].x, -150+Health/maxHealth*300,3*delta)
	modulate=lerp(modulate,Color(1,1,1),delta*2)
	
	Player = get_tree().current_scene.Player
	
	
	velocity=knockbackVelocity+moveVelocity+softCollVelocity
	knockbackVelocity= knockbackVelocity.move_toward(Vector2(0,0),3500*delta)
	
	
	position+=velocity*delta
	
	if softCollider.is_colliding():
		softCollVelocity+=softCollider.get_push_vector()*delta*500
	else:
		softCollVelocity*=0
func take_damage(Damage):
	Health -= Damage
	print(Damage)
	emit_signal("hit")
	if Health <= 0:
		get_tree().current_scene.camera.add_time(timeBonus + globalData.BonusTimeStack)
		if get_tree().current_scene.camera.time <= 30:
			get_tree().current_scene.camera.add_time(timeBonus + globalData.BonusTimeStack + globalData.MoreTime)
		get_tree().current_scene.Player.CanSpeedBoost = true
		call_deferred("queue_free")
		if !deathEmitted:
			deathEmitted=true
			emit_signal("death")
		
	modulate=Color(1,0,0)
	
	$"Health Outline/Health".points[1].x=-150+Health/maxHealth*300

func take_knockback(vector):
	knockbackVelocity=vector*(knockbackMulti + globalData.ExtraKnockback)
	moveVelocity.y =move_toward(moveVelocity.y,vector.y*knockbackMulti,vector.length()*knockbackMulti)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		body.TakeDamage(contactDamage)

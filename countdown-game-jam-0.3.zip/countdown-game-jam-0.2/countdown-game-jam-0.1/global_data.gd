extends Node

var MaxTime := 180.0
var BonusTimeStack := 0.0
var ExtraKnockback := 1.0
var AxetraDamage := 0.0
var AxetraReturnSpeed := 0.0
var SpeedBoost := 0.0
var MoreTime := 0.0

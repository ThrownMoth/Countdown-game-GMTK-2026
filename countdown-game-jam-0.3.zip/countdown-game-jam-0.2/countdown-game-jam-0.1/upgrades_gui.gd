extends Control

var Upgrade1 = ""
var Upgrade2 = ""
var Upgrade3 = ""

func _ready() -> void:
	Upgrade1 = upgradeData.UpgradeArray[randi_range(0,10)]
	Upgrade2 = upgradeData.UpgradeArray[randi_range(0,10)]
	Upgrade3 = upgradeData.UpgradeArray[randi_range(0,10)]
	
	$Panel/Upgrade1.texture_normal = load(upgradeData.Upgrades[Upgrade1][0])
	$Panel/Upgrade1/UpgradeName.text = Upgrade1
	$Panel/Upgrade1/UpgradeDescription.text = upgradeData.Upgrades[Upgrade1][1]
	
	$Panel/Upgrade2.texture_normal = load(upgradeData.Upgrades[Upgrade2][0])
	$Panel/Upgrade2/UpgradeName.text = Upgrade2
	$Panel/Upgrade2/UpgradeDescription.text = upgradeData.Upgrades[Upgrade2][1]
	
	$Panel/Upgrade3.texture_normal = load(upgradeData.Upgrades[Upgrade3][0])
	$Panel/Upgrade3/UpgradeName.text = Upgrade3
	$Panel/Upgrade3/UpgradeDescription.text = upgradeData.Upgrades[Upgrade3][1]


func _on_skip_pressed() -> void:
	get_tree().current_scene.camera.add_time(10)


func _on_upgrade_1_pressed() -> void:
	upgradeData.ApplyUpgrade(Upgrade1)
	call_deferred("queue_free")


func _on_upgrade_2_pressed() -> void:
	upgradeData.ApplyUpgrade(Upgrade2)
	call_deferred("queue_free")

func _on_upgrade_3_pressed() -> void:
	upgradeData.ApplyUpgrade(Upgrade3)
	call_deferred("queue_free")

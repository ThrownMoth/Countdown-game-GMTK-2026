extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0

@onready var Heart := preload("res://heart.tscn")

var MaxTime := globalData.MaxTime
var time := 100.0
var CountdownSpeed := 2.0
var paused := false

var meleeCooldown := 1.0
var Cooldown1 := 0.0
var CanMelee := true

var HeartThrowCooldown := 10
var Cooldown2 := 0.0
var CanHeartThrow := true

func _ready() -> void:
	time = MaxTime

func _physics_process(delta: float) -> void:
	
	
	var direction := Input.get_axis("move_left", "move_right")
	var VertDir := Input.get_axis("move_up","move_down")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	if VertDir:
		velocity.y = VertDir * SPEED
	else:
		velocity.y = move_toward(velocity.y, 0, SPEED)
	
	$body.look_at(get_global_mouse_position())
	
	move_and_slide()
	
	time = max(0,time-CountdownSpeed*delta)
	time = min(time,60 *100-0.01)
	$RichTextLabel.modulate= lerp($RichTextLabel.modulate,Color(1,1,1,$RichTextLabel.modulate.a),delta)
	$RichTextLabel.text="[center]"

	
	if floori(time/60)>9:
		$RichTextLabel.text=$RichTextLabel.text+str(floori(time/60))
	else:
		$RichTextLabel.text=$RichTextLabel.text+"0"+str(floori(time/60))
	if floori(time)%60>9:
		$RichTextLabel.text=$RichTextLabel.text+":"+str(floori(time)%60)
	else:
		$RichTextLabel.text=$RichTextLabel.text+":0"+str(floori(time)%60)
	if floori(time*100)%100>9:
		$RichTextLabel.text=$RichTextLabel.text+"."+str(floori(time*100)%100)
	else:
		$RichTextLabel.text=$RichTextLabel.text+".0"+str(floori(time*100)%100)
	
	if time<=0:
		get_tree().call_deferred("reload_current_scene")
	
	if Cooldown1 <= meleeCooldown:
		Cooldown1 += delta
	else:
		CanMelee = true
		Cooldown1 = 0.0
	
	if Cooldown2 <= HeartThrowCooldown:
		Cooldown2 += delta
	else:
		CanHeartThrow = true
		Cooldown2 = 0.0

func add_time(amount):
	paused=true
	if amount>0:
		$RichTextLabel.modulate=Color(0,min(amount/3,1),0)
	else:
		$RichTextLabel.modulate=Color(min(-amount/3,1),0,0)
	if abs(amount)>=5:
		for i in range(100):
			time+=amount*0.01
			await get_tree().create_timer(0.01).timeout
	else:
		for i in range(floor(abs(amount)*20)):
			time+=0.05*sign(amount)
			await get_tree().create_timer(0.01).timeout
	paused=false

func TakeDamage(damage):
	#time -= damage
	add_time(-damage)
	#ChangeBar()
	if time <= 0:
		globalData.MaxTime -= 20
		get_tree().call_deferred("reload_current_scene")

func ChangeBar():
	$BloodBar.polygon[0].x = -100 + 200*time/MaxTime
	$BloodBar.polygon[3].x = -100 + 200*time/MaxTime

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("left_click"):
		if CanMelee == true:
			CanMelee = false
			add_time(-5)
			$body/HurtBox/CollisionShape2D.disabled = false
			await get_tree().create_timer(0.4).timeout
			$body/HurtBox/CollisionShape2D.disabled = true
	
	if event.is_action_pressed("throw_heart"):
		if CanHeartThrow == true:
			CanHeartThrow = false
			add_time(-30)
			var newHeart = Heart.instantiate()
			get_tree().current_scene.add_child(newHeart)
			newHeart.position = position

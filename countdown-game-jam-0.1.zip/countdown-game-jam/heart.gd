extends Area2D

var Speed = 500

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(3).timeout
	call_deferred("queue_free")

func _physics_process(delta: float) -> void:
	position += transform.x * Speed* delta

extends Node

var MaxTime := 100.0

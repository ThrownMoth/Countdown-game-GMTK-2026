extends Node2D

var time:=10.0
var countdownSpeed:=1.0
var blinking = false
var paused=false
var debugAddTimeAmount:=3.0
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:

	if !blinking and !paused:
		time =max (0,time-countdownSpeed*delta)
		time=min(time,60*100-0.01)
		$RichTextLabel.modulate= lerp($RichTextLabel.modulate,Color(1,1,1,$RichTextLabel.modulate.a),delta)
	$RichTextLabel.text="[center]"

	if floori(time/60)>9:
		$RichTextLabel.text=$RichTextLabel.text+str(floori(time/60))
	else:
		$RichTextLabel.text=$RichTextLabel.text+"0"+str(floori(time/60))


	if floori(time)%60>9:
		$RichTextLabel.text=$RichTextLabel.text+":"+str(floori(time)%60)
	else:
		$RichTextLabel.text=$RichTextLabel.text+":0"+str(floori(time)%60)
	
	if floori(time*100)%100>9:
		$RichTextLabel.text=$RichTextLabel.text+"."+str(floori(time*100)%100)
	else:
		$RichTextLabel.text=$RichTextLabel.text+".0"+str(floori(time*100)%100)
	
	
	
#ff3886
func add_time(amount):
	paused=true
	if amount>0:
		$RichTextLabel.modulate=Color(0,min(amount/3,1),0)
	else:
		$RichTextLabel.modulate=Color(min(-amount/3,1),0,0)
	if abs(amount)>=5:
		for i in range(100):
			time+=amount*0.01
			await get_tree().create_timer(0.01).timeout
	else:
		for i in range(floor(abs(amount)*20)):
			time+=0.05*sign(amount)
			await get_tree().create_timer(0.01).timeout
	paused=false
func blink(blinkColour,duration,speed):
	blinking=true
	var startColour=$RichTextLabel.self_modulate
	for i in (ceil(duration*speed)):
		var newTween=get_tree().create_tween()
		var secondTween = get_tree().create_tween()
		newTween.tween_property($RichTextLabel,^"self_modulate",blinkColour,duration/speed*0.5)
		await get_tree().create_timer(duration/speed*0.5).timeout
		secondTween.tween_property($RichTextLabel,^"self_modulate",startColour,duration/speed*0.5)
		await get_tree().create_timer(duration/speed*0.5).timeout

func _input(_event: InputEvent) -> void:
	if Input.is_action_just_pressed("ui_right"):
		add_time(debugAddTimeAmount)
	if Input.is_action_just_pressed("ui_left"):
		add_time(-debugAddTimeAmount)
	if Input.is_action_just_pressed("ui_up"):
		debugAddTimeAmount+=1
	if Input.is_action_just_pressed("ui_down"):
		debugAddTimeAmount-=1
#	if Input.is_action_just_pressed("ui_accept"):
#		blink(Color(0,0,0,0),1,5)

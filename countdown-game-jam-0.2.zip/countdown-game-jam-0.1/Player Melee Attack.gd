extends Area2D

var damage:=3.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	modulate.a-=delta*3
	if modulate.a<=0:
		call_deferred("queue_free")



func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy"):
		area.take_damage(damage)

extends CharacterBody2D


const SPEED = 600.0
const JUMP_VELOCITY = -400.0

@onready var Heart := preload("res://heart.tscn")
@onready var meleeAttack:=preload("res://Melee Attack.tscn") 
@onready var axeThrow:=preload("res://Thrown Axe.tscn")

var meleeCooldown := 1.0
var Cooldown1 := 0.0
var CanMelee := true

var HeartThrowCooldown := 4
var Cooldown2 := 0.0
var CanHeartThrow := true
var axeThrown:=false


func _physics_process(delta: float) -> void:
	
	
	var direction := Input.get_axis("move_left", "move_right")
	var VertDir := Input.get_axis("move_up","move_down")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	if VertDir:
		velocity.y = VertDir * SPEED
	else:
		velocity.y = move_toward(velocity.y, 0, SPEED)
	
	$body.look_at(get_global_mouse_position())
	
	move_and_slide()

	if Cooldown1 <= meleeCooldown:
		Cooldown1 += delta
	else:
		CanMelee = true
		Cooldown1 = 0.0
	
	if Cooldown2 <= HeartThrowCooldown:
		Cooldown2 += delta
	else:
		CanHeartThrow = true
		Cooldown2 = 0.0



func TakeDamage(damage):
	get_parent().camera.add_time(-damage)
#	ChangeBar()
	if get_parent().time <= 0:
		globalData.MaxTime -= 20
		get_tree().call_deferred("reload_current_scene")

#func ChangeBar():
#	$BloodBar.polygon[0].x = -100 + 200*time/MaxTime
#	$BloodBar.polygon[3].x = -100 + 200*time/MaxTime

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("left_click"):
		if CanMelee == true and !axeThrown:
			CanMelee = false
			#get_parent().camera.add_time(-5)
			var newMelee=meleeAttack.instantiate()
			get_tree().current_scene.add_child(newMelee)
			newMelee.position=position
			newMelee.rotation=self.get_angle_to(get_global_mouse_position())
	
	if event.is_action_pressed("right_click"):
		if !axeThrown:
			axeThrown=true
			var newAxe=axeThrow.instantiate()
			get_tree().current_scene.add_child(newAxe)
			newAxe.position=position
			newAxe.angle=self.get_angle_to(get_global_mouse_position())
	
	if event.is_action_pressed("throw_heart"):
		if CanHeartThrow == true:
			CanHeartThrow = false
			get_parent().camera.add_time(-5)
			var newHeart = Heart.instantiate()
			get_tree().current_scene.add_child(newHeart)
			newHeart.position = position
			newHeart.angle=velocity.angle()
